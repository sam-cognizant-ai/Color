import json
from contradiction_enhanced import analyze_contradiction  # Import the function directly from contradiction.py


# Step 1: Extract contradicting 'exact_statement' from the contradiction results
def extract_contradicted_exact_statements_from_results(contradiction_results):
    """Extract the 'exact_statement' where the 'evaluation' is 'contradict'."""
    contradicting_statements = []

    # Extract contradicting 'exact_statement' values
    for pair in contradiction_results.get('pairs', []):
        if 'contradict' in pair.get('evaluation', '').lower():
            contradicting_statements.append(pair['exact_statement'])

    return contradicting_statements


# Step 2: Find the indices of contradicting answers in the paragraph text
def line_start_end_index_from_file(lines_to_check):
    # Hardcoded file path for the paragraph content
    file_path = 'paragraph.txt'  # Change this to the path of your file

    try:
        # Open the file and read its content
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        return f"The file '{file_path}' was not found."

    # Initialize a list to store the indices for all lines
    all_indices = []

    for line_to_check in lines_to_check:
        # Strip leading/trailing whitespace from the line to check
        line_to_check = line_to_check.strip()
        indices = []
        start_index = 0

        while True:
            # Find the start index of the next occurrence of the substring
            start_index = text.find(line_to_check, start_index)

            if start_index == -1:
                break  # No more occurrences found

            # Offset start_index by -2 if valid
            adjusted_start_index = max(0, start_index - 2)

            # Offset end_index by -2 if valid
            adjusted_end_index = max(0, start_index + len(line_to_check) - 1 - 2)

            indices.append([adjusted_start_index, adjusted_end_index])

            # Move the start_index forward to avoid overlapping results
            start_index += 1

        # Add the indices for the current line to the result
        if indices:
            all_indices.extend(indices)

    # Format the result according to the specified structure
    result = {
        "range": {
            "input": {
                "red": all_indices,  # Add all the indices to the 'red' list
                "green": []
            },
            "summary": {
                "red": [],  # Empty list for the 'summary' section
                "green": []
            }
        }
    }

    return result


# Function to extract dynamic data and return table format and range
def extract_dynamic_data(response):
    tableFormat = []
    range_info = None

    for key, value in response.items():
        if isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
            tableFormat = [
                {k: v for k, v in item.items()} for item in value
            ]

        if key == "range":
            range_info = value

    return tableFormat, range_info


# Main function
def main():
    # Step 1: Get the conversation and key takeaways
    file_path = 'paragraph.txt'
    with open(file_path, 'r') as file:
        call_conversation = file.read()

    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Step 2: Analyze the contradiction results
    contradiction_results = analyze_contradiction(call_conversation, kt)

    # Step 3: Extract contradicting 'exact_statement'
    contradicting_statements = extract_contradicted_exact_statements_from_results(contradiction_results)

    # Step 4: Find the indices of the contradicting 'exact_statement' in 'paragraph.txt'
    result = line_start_end_index_from_file(contradicting_statements)

    # Step 5: Append the range to the contradiction results
    contradiction_results['range'] = result['range']  # Add the range at the end

    # Step 6: Extract dynamic data using the new function
    tableFormat, range_info = extract_dynamic_data(contradiction_results)

    # Step 8: Print the table format and range info
    print("\nExtracted Table Format:")
    print(json.dumps(tableFormat, indent=4))
    print("\nExtracted Range Info:")
    print(json.dumps(range_info, indent=4))


if __name__ == "__main__":
    main()
