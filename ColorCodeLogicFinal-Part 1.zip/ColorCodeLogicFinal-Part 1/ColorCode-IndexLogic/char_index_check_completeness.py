import json
from completeness_enhanced import analyze_completeness  # Import the function directly from contradiction.py


def extract_completeness_exact_lines_missing_from_results(completeness_results):
    """
    Extract all 'exact_lines_missing' from the completeness results.

    Args:
        completeness_results (dict): The output dictionary containing completeness evaluation details.

    Returns:
        list: A list of strings containing all 'exact_lines_missing' from the results.
    """
    exact_lines_missing = []

    # Traverse the missing information details to extract 'exact_lines_missing'
    for detail in completeness_results.get("missing_information_details", []):
        lines = detail.get("exact_lines_missing", [])
        exact_lines_missing.extend(lines)

    return exact_lines_missing


# Step 2: Find the indices of contradicting answers in the paragraph text
def line_start_end_index_from_file(lines_to_check):
    # Hardcoded file path for the paragraph content
    file_path = 'paragraph.txt'  # Change this to the path of your file

    try:
        # Open the file and read its content
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        return f"The file '{file_path}' was not found."

    # Initialize a list to store the indices for all lines
    all_indices = []

    for line_to_check in lines_to_check:
        # Strip leading/trailing whitespace from the line to check
        line_to_check = line_to_check.strip()
        indices = []
        start_index = 0

        while True:
            # Find the start index of the next occurrence of the substring
            start_index = text.find(line_to_check, start_index)

            if start_index == -1:
                break  # No more occurrences found

            # Calculate the end index of the line (substring)
            end_index = start_index + len(line_to_check) - 1
            indices.append([start_index, end_index])

            # Move the start_index forward to avoid overlapping results
            start_index += 1

        # Add the indices for the current line to the result
        if indices:
            all_indices.extend(indices)

    # Format the result according to the specified structure
    result = {
        "range": {
            "input": {
                "red": [],  # Add all the indices to the 'red' list
                "green": []
            },
            "summary": {
                "red": all_indices,  # Empty list for the 'summary' section
                "green": []
            }
        }
    }

    return result


# Function to extract dynamic data and return table format and range
def extract_dynamic_data(response):
    tableFormat = []
    range_info = None

    for key, value in response.items():
        if isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
            tableFormat = [
                {k: v for k, v in item.items()} for item in value
            ]

        if key == "range":
            range_info = value

    return tableFormat, range_info


# Main function
def main():
    # Step 1: Get the conversation and key takeaways
    file_path = 'paragraph.txt'
    with open(file_path, 'r') as file:
        call_conversation = file.read()

    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Step 2: Analyze the completeness results
    completeness_results = analyze_completeness(call_conversation, kt)

    # Step 3: Extract completeness 'exact_lines_missing'
    completeness_statements = extract_completeness_exact_lines_missing_from_results(completeness_results)

    # Step 4: Find the indices of the completeness 'exact_lines_missing' in 'paragraph.txt'
    result = line_start_end_index_from_file(completeness_statements)

    # Step 5: Append the range to the completeness results
    completeness_results['range'] = result['range']  # Add the range at the end

    # Step 6: Extract dynamic data using the new function
    tableFormat, range_info = extract_dynamic_data(completeness_results)

    # Step 8: Print the table format and range info
    print("\nExtracted Table Format:")
    print(json.dumps(tableFormat, indent=4))
    print("\nExtracted Range Info:")
    print(json.dumps(range_info, indent=4))


if __name__ == "__main__":
    main()
