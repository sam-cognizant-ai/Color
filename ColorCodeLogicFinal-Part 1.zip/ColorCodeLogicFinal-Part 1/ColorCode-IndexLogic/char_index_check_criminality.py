import json
from criminality_enhanced import analyze_criminality  # Import the function directly from contradiction.py


# Step 1: Extract contradicting 'exact_statement' from the contradiction results
def extract_criminality_exact_statement(criminality_results):
    """Extract 'exact_lines' values from the criminality results."""
    criminality_statements = []

    # Iterate over each entry in the 'results' list
    if 'exact_lines' in criminality_results:
        criminality_statements.extend(criminality_results['exact_lines'])

    return criminality_statements


# Step 2: Find the indices of contradicting answers in the paragraph text
def line_start_end_index_from_file(lines_to_check):
    # Hardcoded file path for the paragraph content
    file_path = 'summary.txt'  # Change this to the path of your file

    try:
        # Open the file and read its content
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        return f"The file '{file_path}' was not found."

    # Initialize a list to store the indices for all lines
    all_indices = []

    for line_to_check in lines_to_check:
        # Strip leading/trailing whitespace from the line to check
        line_to_check = line_to_check.strip()
        indices = []
        start_index = 0

        while True:
            # Find the start index of the next occurrence of the substring
            start_index = text.find(line_to_check, start_index)

            if start_index == -1:
                break  # No more occurrences found

            # Calculate the end index of the line (substring)
            end_index = start_index + len(line_to_check) - 1
            indices.append([start_index, end_index])

            # Move the start_index forward to avoid overlapping results
            start_index += 1

        # Add the indices for the current line to the result
        if indices:
            all_indices.extend(indices)

    # Format the result according to the specified structure
    result = {
        "range": {
            "input": {
                "red": [],  # Add all the indices to the 'red' list
                "green": []
            },
            "summary": {
                "red": all_indices,  # Empty list for the 'summary' section
                "green": []
            }
        }
    }

    return result


# Function to extract dynamic data and return table format and range
def extract_dynamic_data(response):
    tableFormat = []
    range_info = None

    for key, value in response.items():
        if isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
            tableFormat = [
                {k: v for k, v in item.items()} for item in value
            ]

        if key == "range":
            range_info = value

    return tableFormat, range_info


# Main function
def main():
    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Step 2: Analyze the criminality results
    criminality_results = analyze_criminality(kt)

    # Step 3: Extract criminality 'exact_statement'
    criminality_statements = extract_criminality_exact_statement(criminality_results)

    # Step 4: Find the indices of the criminality 'exact_statement' in 'summary.txt'
    result = line_start_end_index_from_file(criminality_statements)

    # Step 5: Append the range to the criminality results
    criminality_results['range'] = result['range']  # Add the range at the end

    # Step 6: Extract dynamic data using the new function
    tableFormat, range_info = extract_dynamic_data(criminality_results)

    # Step 8: Print the table format and range info
    print("\nExtracted Table Format:")
    print(json.dumps(tableFormat, indent=4))
    print("\nExtracted Range Info:")
    print(json.dumps(range_info, indent=4))


if __name__ == "__main__":
    main()
