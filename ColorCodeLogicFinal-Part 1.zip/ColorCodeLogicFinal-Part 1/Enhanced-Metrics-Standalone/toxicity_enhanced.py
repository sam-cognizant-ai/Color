import json
import os
import logging
from langchain.chat_models import AzureChatOpenAI

os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"


def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def llm_toxicity_analysis(chat_model, summary):
    template = (
        "Please analyze the summary if ot has any toxic words that includes offensive swear words as well and assign "
        "a toxicity score between 0 and 1,"
        "where 1 means highly relevant and 0 means not relevant at all. "
        "Be as specific as possible and provide reasoning behind your judgment.\n\n"
        "Return the results in JSON format with the following keys:"
        " - 'score': Provide a  score based on your analysis"
        " - 'reasoning': Detailed reasoning behind the score."
        " - 'exact_lines': Provide me with the exact lines in the summary where toxicity was detected wrapped as a list"
        "\n\n"
        "Summary: '''{}'''\n\n"
    ).format(summary)

    try:
        response = chat_model.call_as_llm(template)
        # Remove backticks and parse JSON
        if response.startswith("```json"):
            response = response.strip("```json").strip("```")
        return json.loads(response)
    except json.JSONDecodeError as e:
        logging.error("Failed to parse response as JSON: %s", e)
        return {"error": "Failed to parse response as JSON", "raw_response": response}


def analyze_toxicity(summary, temperature=0.0):
    """ Analyze the text for toxicity using the LLM. """
    chat_model = initialize_chat_model(temperature)
    llm_judgment = llm_toxicity_analysis(chat_model, summary)
    return llm_judgment


if __name__ == "__main__":
    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Initialize the chat model before passing it to llm_pii_analysis
    chat_model = initialize_chat_model()

    # Pass both chat_model and summary (kt)
    kt_toxicity_analysis = llm_toxicity_analysis(chat_model, kt)

    # Pretty print JSON output
    print(json.dumps(kt_toxicity_analysis, indent=4))
