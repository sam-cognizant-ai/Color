import re
import logging
import os
import json
from langchain_community.chat_models import AzureChatOpenAI

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Set environment variables
os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"


# Initialize Azure OpenAI GPT model
def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


# Function to analyze QA Score
def llm_QA_Score_analysis(chat_model, key_takeaways, call):
    template = (
        "Generate 15 questions based on the call conversation."
        "Answer each of the generated questions and evaluate the answer."
        "Give me the exact statement from call conversation from which the answer was framed (remove any speaker tags like 'CSR:' or 'Customer:')."
        "Analyze how many questions of the total questions are answered correctly."
        "Assign the score by the following: Total number of questions answered correct / Total number of questions."
        "Where 1 means a good QA score and 0 means a poor QA score."
        "Be as specific as possible and provide reasoning behind your judgment."
        "Return the results in JSON format with the following keys:"
        " - 'questions': A list of questions with answers, exact_statement and evaluation"
        " - 'correct_count': Total number of correct answers"
        " - 'total_questions': Total number of questions"
        " - 'qa_score': The calculated QA score (correct_count/total_questions)"
        " - 'reasoning': Detailed reasoning behind the QA score."
        "\n\n"
        "summary: '''{}'''\n\n"
        "call conversation: '''{}'''\n\n"
        "JSON Response: "
    ).format(key_takeaways, call)

    response = chat_model.call_as_llm(template)
    # logging.info(f"Raw Response: {response}")
    return response


def analyze_qa_score(key_takeaways, call, temperature=0.0):
    """Analyze the QA score with LLM and return results in JSON format."""
    chat_model = initialize_chat_model(temperature)

    llm_response = llm_QA_Score_analysis(chat_model, key_takeaways, call)

    # Remove code block markers if present
    cleaned_response = llm_response.strip()
    if cleaned_response.startswith("```json"):
        cleaned_response = cleaned_response[7:]  # Remove ```json
    if cleaned_response.endswith("```"):
        cleaned_response = cleaned_response[:-3]  # Remove trailing ```

    try:
        # Parse the JSON response
        parsed_response = json.loads(cleaned_response)
        # logging.info(f"Parsed Response: {parsed_response}")
        return parsed_response
    except json.JSONDecodeError as e:
        logging.error(f"Failed to decode JSON: {e}")
        return {
            "error": "Invalid JSON response",
            "raw_response": cleaned_response
        }


# Example usage
if __name__ == "__main__":


    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        key_takeaways = file.read()

    file_path = 'paragraph.txt'
    with open(file_path, 'r') as file:
        call_conversation = file.read()

    # Analyze QA Score
    result = analyze_qa_score(key_takeaways, call_conversation)

    # Print the JSON response for visualization
    print(json.dumps(result, indent=4))
