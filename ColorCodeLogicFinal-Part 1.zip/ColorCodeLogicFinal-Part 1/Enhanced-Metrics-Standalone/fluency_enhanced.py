import json
import logging
import os
from langchain_community.chat_models import AzureChatOpenAI

os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"


def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def llm_fluency_analysis(chat_model, summary):
    template = (
        "Please review the following summary for language fluency."
        "Provide a score where 1 means good fluency and 0 means poor fluency. "
        "For each identified instance, provide a brief reasoning of the disfluency occurred."
        "Return the results in JSON format with the following keys:\n"
        " - 'score': Provide a fluency score based on your analysis.\n"
        " - 'reasoning': Detailed reasoning behind the fluency score.\n"
        "- 'exact_lines': Provide me with the exact lines in the summary where disfluency was detected, wrapped as a "
        "list.\n\n"
        "Summary: '''{}'''\n\n"
    ).format(summary)

    try:
        response = chat_model.call_as_llm(template)
        # Remove backticks and parse JSON
        if response.startswith("```json"):
            response = response.strip("```json").strip("```")
        return json.loads(response)
    except json.JSONDecodeError as e:
        logging.error("Failed to parse response as JSON: %s", e)
        return {"error": "Failed to parse response as JSON", "raw_response": response}


def analyze_fluency(summary, temperature=0.0):
    """ Analyze the text for misogyny using the LLM. """
    chat_model = initialize_chat_model(temperature)
    llm_judgment = llm_fluency_analysis(chat_model, summary)
    return llm_judgment


# Example usage
if __name__ == "__main__":
    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Initialize the chat model before passing it to llm_fluency_analysis
    chat_model = initialize_chat_model()

    # Pass both chat_model and summary (kt)
    kt_fluency_analysis = llm_fluency_analysis(chat_model, kt)

    # Pretty print JSON output
    print(json.dumps(kt_fluency_analysis, indent=4))
