import logging
import os
import json
from langchain_community.chat_models import AzureChatOpenAI

# Set environment variables
os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


# Initialize Azure OpenAI GPT-4 model for LLM-based analysis
def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def llm_contradiction_analysis(chat_model, call_conversation, kt):
    template = (
        "Generate a list of fifteen questions based on the call conversation and key takeaways (kt). "
        "For each question, provide the following: "
        "1. The answer based on the key takeaways (kt). "
        "2. The answer based on the call conversation. "
        "3. The exact statement from call conversation from which the answer was framed (remove any speaker tags like 'CSR:' or 'Customer:')."
        "4. An evaluation of whether the answers match or contradict. "
        "5. A contradiction score, calculated as match_count / total_count. "
        "where 1 means no contradiction score and 0 means high contradiction score."
        "6. Be as specific as possible and provide reasoning behind your judgment.\n\n"
        "Provide the output in JSON format with the following keys:\n"
        "1. 'pairs': A list where each element is a dictionary containing 'question', 'kt_answer', 'call_conversation_answer', 'exact_statement' and 'evaluation'\n"
        "2. 'match_count': Number of correctly matched 'kt_answer' with 'call_conversation_answer'\n"
        "3. 'total_count': Total number of questions\n"
        "4. 'score': Contradiction score (match_count / total_count)\n"
        "5. 'reasoning': Detailed reasoning behind the score\n\n"
        "Call conversation: '''{}'''\n\n"
        "Key takeaways: '''{}'''\n\n"
    ).format(call_conversation, kt)

    try:
        response = chat_model.call_as_llm(template)
        # Remove backticks and parse JSON
        if response.startswith("```json"):
            response = response.strip("```json").strip("```")
        return json.loads(response)
    except json.JSONDecodeError as e:
        logging.error("Failed to parse response as JSON: %s", e)
        return {"error": "Failed to parse response as JSON", "raw_response": response}



def analyze_contradiction(call_conversation, kt, temperature=0.0):
    """Analyze the call conversation and key takeaways for contradictions and scoring."""
    chat_model = initialize_chat_model(temperature)
    llm_judgment = llm_contradiction_analysis(chat_model, call_conversation, kt)
    return llm_judgment


# Main script
if __name__ == "__main__":
    file_path = 'paragraph.txt'
    with open(file_path, 'r') as file:
        call_conversation = file.read()

    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    kt_Doc_Score_analysis = analyze_contradiction(call_conversation, kt)

    # Pretty print JSON output
    print(json.dumps(kt_Doc_Score_analysis, indent=4))
