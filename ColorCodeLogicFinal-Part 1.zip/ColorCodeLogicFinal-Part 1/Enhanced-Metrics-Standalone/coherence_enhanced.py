import os
import json
from langchain.chat_models import AzureChatOpenAI

# Set environment variables
os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"


# Initialize Azure OpenAI GPT-3.5/4 model
def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


# Function for coherence analysis with JSON output
def llm_coherence_analysis(chat_model, summary):
    # Expanded prompt with key_takeaways as a single text block
    template = (
        "Analyze the coherence of the following summary, providing detailed observations and suggestions for improvement. "
        "Consider logical flow, clarity, and ambiguity. Additionally, provide a revised version of the summary and consolidate "
        "the key takeaways into a single, coherent paragraph.\n\n"
        "Provide the output strictly in JSON format with the following keys:\n"
        "1. 'score': A numerical rating of coherence (0-1) where 1 indicates perfect coherence.\n"
        "2. 'reasoning': Detailed reasoning behind the assigned score, including an analysis of logical flow, clarity, and effectiveness.\n"
        "3. 'observations_and_suggestions': A list of observations and suggestions for improvement, where each element is a dictionary containing:\n"
        "   - 'observation': The specific observation regarding the summary.\n"
        "   - 'original': The original text from the summary that is being analyzed.\n"
        "   - 'revised': The suggested improvement or revision for that text.\n"
        "4. 'revised_summary_and_key_takeaways': A single, revised version of the summary along with a condensed paragraph summarizing the key takeaways from the revised summary.\n\n"
        "Summary: '''{}'''\n\n"
        "Respond strictly in JSON format."
    ).format(summary)

    # Call the model
    response = chat_model.call_as_llm(template)

    # Clean up the response to remove code block markers
    cleaned_response = response.strip("```json").strip("```").strip()

    try:
        # Parse and return JSON response
        response_json = json.loads(cleaned_response)
    except json.JSONDecodeError:
        response_json = {"error": "Failed to parse LLM response as JSON", "raw_response": response}

    return response_json


# Analyze coherence with LLM
def analyze_coherence(summary, temperature=0.0):
    chat_model = initialize_chat_model(temperature)
    return llm_coherence_analysis(chat_model, summary)


# Main execution
if __name__ == "__main__":
    # Load summary from file (example)
    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        summary = file.read()

    # Analyze coherence
    coherence_analysis = analyze_coherence(summary)

    # Print the JSON response
    print(json.dumps(coherence_analysis, indent=4))
