import json
import logging
import os
from langchain.chat_models import AzureChatOpenAI

os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def initialize_chat_model(temperature=0.0):
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def llm_pii_analysis(chat_model, summary):
    template = (
        "You are an AI tasked with reviewing a conversation summary to identify any Personally Identifiable"
        "Information (PII). PII includes, but is not limited to, the following types of data:"

        "Full Names: First and last names of individuals."

        "Financial Information: Credit card numbers, CVV codes, bank account details."
        "Assign a score between 0 and 1. 1 means pii observed  and 0 means no pii observed."
        "Return the results in JSON format with the following keys:"
        " - 'score': Provide a  score based on your analysis"
        " - 'reasoning': Detailed reasoning behind the score."
        " - 'exact_lines': Provide me with the exact lines in the summary where pii was detected"
        "\n\n"

        "summary: '''{}'''\n\n"
        "Score: "
    ).format(summary)

    try:
        response = chat_model.call_as_llm(template)
        # Remove backticks and parse JSON
        if response.startswith("```json"):
            response = response.strip("```json").strip("```")
        return json.loads(response)
    except json.JSONDecodeError as e:
        logging.error("Failed to parse response as JSON: %s", e)
        return {"error": "Failed to parse response as JSON", "raw_response": response}


def analyze_pii(summary, temperature=0.0):
    """ Analyze the text for misogyny using the LLM. """
    chat_model = initialize_chat_model(temperature)
    llm_judgment = llm_pii_analysis(chat_model, summary)
    return llm_judgment


if __name__ == "__main__":
    file_path = 'summary.txt'
    with open(file_path, 'r') as file:
        kt = file.read()

    # Initialize the chat model before passing it to llm_pii_analysis
    chat_model = initialize_chat_model()

    # Pass both chat_model and summary (kt)
    kt_pii_analysis = llm_pii_analysis(chat_model, kt)

    # Pretty print JSON output
    print(json.dumps(kt_pii_analysis, indent=4))
