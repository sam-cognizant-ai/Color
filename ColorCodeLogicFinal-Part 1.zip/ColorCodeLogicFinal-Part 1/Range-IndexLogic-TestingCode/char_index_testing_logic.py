def extract_text_by_range(file_path, start, end):
    """
    Extracts text from a file within the specified character range.

    Args:
        file_path (str): Path to the text file.
        start (int): Starting position of the range (inclusive).
        end (int): Ending position of the range (inclusive).

    Returns:
        str: Extracted text within the specified range.
    """
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            file_content = file.read()  # Read the entire file as a string
            if start < 0 or end > len(file_content):
                raise ValueError(f"Range {start}-{end} is out of bounds for the file with length {len(file_content)}.")
            return file_content[start:end + 1]  # Extract the range
    except FileNotFoundError:
        return f"Error: File not found at {file_path}."
    except Exception as e:
        return f"Error: {str(e)}"


# Example usage:
file_path = "summary.txt"  # Path to your text file
start_range = 18
end_range = 115
extracted_text = extract_text_by_range(file_path, start_range, end_range)
print("Extracted Text:\n", extracted_text)