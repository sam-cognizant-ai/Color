import json
import logging
import os
import re
from langchain_community.chat_models import AzureChatOpenAI
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)

# Set environment variables for both contradiction and completeness analyses
os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')


def initialize_chat_model(temperature=0.0):
    """ Initialize Azure Chat Model. """
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def call_as_llm(chat_model, template):
    """ Execute the template query on the model and return the parsed JSON result. """
    response = chat_model.call_as_llm(template)
    cleaned_response = re.sub(r'```json\n|\n```', '', response).strip()
    try:
        return json.loads(cleaned_response)
    except json.JSONDecodeError:
        logging.error("Response is not in JSON format. Returning raw text.")
        return {"error": "Response is not in valid JSON format", "raw_response": response}


def analyze_text(chat_model, paragraph, summary, analysis_type):
    """ Analyze the text for contradiction or completeness depending on the analysis type. """
    if analysis_type == "contradiction":
        template = (
            "Generate a list of fifteen questions based on the call conversation and key takeaways (kt). "
            "For each question, provide the following: "
            "1. The answer based on the key takeaways (kt). "
            "2. The answer based on the call conversation. "
            "3. The exact statement from call conversation from which the answer was framed (remove any speaker tags like 'CSR:' or 'Customer:')."
            "4. An evaluation of whether the answers match or contradict. "
            "5. A contradiction score, calculated as match_count / total_count. "
            "where 1 means no contradiction score and 0 means high contradiction score."
            "6. Be as specific as possible and provide reasoning behind your judgment.\n\n"
            "Provide the output in JSON format with the following keys:\n"
            "1. 'pairs': A list where each element is a dictionary containing 'question', 'kt_answer', 'call_conversation_answer', 'exact_statement' and 'evaluation'\n"
            "2. 'match_count': Number of correctly matched 'kt_answer' with 'call_conversation_answer'\n"
            "3. 'total_count': Total number of questions\n"
            "4. 'score': Contradiction score (match_count / total_count)\n"
            "5. 'reasoning': Detailed reasoning behind the score\n\n"
            "Call conversation: '''{}'''\n\n"
            "Key takeaways: '''{}'''\n\n"
            ).format(paragraph, summary)
    elif analysis_type == "completeness":
        template = (
            "You are an intuitive agent tasked with comparing a call conversation and its summary. Your goal is to assess "
            "whether the summary fully captures all the information in the call conversation."
            "Identify the primary goal of the document and the essential points or arguments it makes."
            "Read the provided summary and compare it with the call conversation."
            "Check if all the information of the call conversation are present in the summary."
            "If any information is missing from the summary, list all the missing details in bullet points."
            "For each missing point, provide a detailed explanation of what is missing."
            "Display the exact lines from the call conversation that convey the missing information."
            "Based on your analysis, assign a score between 0 and 1 to the summary."
            "If more than two missing information is found then significantly reduce the score."
            "0 means the summary misses most or all of the crucial points."
            "1 means the summary captures all important details accurately."
            "list down the highlighted lines in separate lines instead of gpt generated way."
            "call conversation: '''{}'''\n\n"
            "Summary: '''{}'''\n\n"
            "Provide output in a JSON format with the following keys:\n"
            " - score: The completeness score between 0 and 1.\n"
            " - reasoning: The reasoning behind your score.\n"
            " - missing_information_details: A list of objects, each containing:\n"
            "    - missing_point: The missing point in the summary\n"
            "    - explanation: A detailed explanation of the missing point\n"
            "    - exact_lines_missing: A list of exact lines from the conversation."
        ).format(paragraph, summary)
    elif analysis_type == "qa_score":
        template = (
            "Generate 15 questions based on the call conversation."
            "Answer each of the generated questions and evaluate the answer."
            "Give me the exact statement from call conversation from which the answer was framed (remove any speaker tags like 'CSR:' or 'Customer:')."
            "Analyze how many questions of the total questions are answered correctly."
            "Assign the score by the following: Total number of questions answered correct / Total number of questions."
            "Where 1 means a good QA score and 0 means a poor QA score."
            "Be as specific as possible and provide reasoning behind your judgment."
            "Return the results in JSON format with the following keys:"
            " - 'questions': A list of questions with answers, exact_statement and evaluation"
            " - 'correct_count': Total number of correct answers"
            " - 'total_questions': Total number of questions"
            " - 'qa_score': The calculated QA score (correct_count/total_questions)"
            " - 'reasoning': Detailed reasoning behind the QA score."
            "\n\n"
            "summary: '''{}'''\n\n"
            "call conversation: '''{}'''\n\n"
            "JSON Response: "
        ).format(paragraph, summary)
    elif analysis_type == "coherence":
        template = (
            "Analyze the coherence of the following summary, providing detailed observations and suggestions for improvement. "
            "Consider logical flow, clarity, and ambiguity. Additionally, provide a revised version of the summary and consolidate "
            "the key takeaways into a single, coherent paragraph.\n\n"
            "Provide the output strictly in JSON format with the following keys:\n"
            "1. 'score': A numerical rating of coherence (0-1) where 1 indicates perfect coherence.\n"
            "2. 'reasoning': Detailed reasoning behind the assigned score, including an analysis of logical flow, clarity, and effectiveness.\n"
            "3. 'observations_and_suggestions': A list of observations and suggestions for improvement, where each element is a dictionary containing:\n"
            "   - 'observation': The specific observation regarding the summary.\n"
            "   - 'original': The original text from the summary that is being analyzed.\n"
            "   - 'revised': The suggested improvement or revision for that text.\n"
            "4. 'revised_summary_and_key_takeaways': A single, revised version of the summary along with a condensed paragraph summarizing the key takeaways from the revised summary.\n\n"
            "Summary: '''{}'''\n\n"
            "Respond strictly in JSON format."
        ).format(summary)

    return call_as_llm(chat_model, template)


def extract_statements_from_results(results, analysis_type):
    """ Extract statements based on evaluation (contradict or missing) from the results. """
    statements = []
    if analysis_type == "contradiction":
        for pair in results.get('pairs', []):
            if 'contradict' in pair.get('evaluation', '').lower():
                statements.append(pair['exact_statement'])
    elif analysis_type == "completeness":
        for detail in results.get("missing_information_details", []):
            statements.extend(detail.get("exact_lines_missing", []))
    elif analysis_type == "qa_score":
        for question in results.get('questions', []):
            if 'incorrect' in question.get('evaluation', '').lower():
                statements.extend(question['exact_statement'])
    elif analysis_type == "coherence":
        for detail in results.get("observations_and_suggestions", []):
            statements.append(detail.get("original", ""))
    return statements


def line_start_end_index_from_file(lines_to_check, analysis_type, file_path='paragraph.txt'):
    """ Find the indices of lines to check in the provided file. """
    try:
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        return f"The file '{file_path}' was not found."

    all_indices = []
    for line_to_check in lines_to_check:
        line_to_check = line_to_check.strip()
        indices = []
        start_index = 0
        while True:
            start_index = text.find(line_to_check, start_index)
            if start_index == -1:
                break
            end_index = start_index + len(line_to_check) - 1
            indices.append([start_index, end_index])
            start_index += 1
        if indices:
            all_indices.extend(indices)

    if analysis_type == "coherence":
        return {"range": {"input": {"red": [], "green": []}, "summary": {"red": all_indices, "green": []}}}
    return {"range": {"input": {"red": all_indices, "green": []}, "summary": {"red": [], "green": []}}}



def extract_dynamic_data(response):
    """ Extract dynamic data from the response and return in table format. """
    table_format = []
    range_info = None
    for key, value in response.items():
        if isinstance(value, list) and len(value) > 0 and isinstance(value[0], dict):
            table_format = [{k: v for k, v in item.items()} for item in value]
        if key == "range":
            range_info = value
    return table_format, range_info


def analyze_metrics(paragraph, summary, analysis_type, temperature=0.0):
    """ Analyze contradiction or completeness depending on the specified analysis type. """
    chat_model = initialize_chat_model(temperature)
    analysis_results = analyze_text(chat_model, paragraph, summary, analysis_type)
    extracted_statements = extract_statements_from_results(analysis_results, analysis_type)
    if analysis_type == "coherence":
        range_info = line_start_end_index_from_file(extracted_statements, analysis_type, file_path="summary.txt")
    else:
        range_info = line_start_end_index_from_file(extracted_statements, analysis_type)
    analysis_results['range'] = range_info['range']
    table_format, range_info = extract_dynamic_data(analysis_results)
    return table_format, range_info


# Main script
if __name__ == "__main__":
    # Load conversation and summary files
    with open('paragraph.txt', 'r') as file:
        paragraph = file.read()

    with open('summary.txt', 'r') as file:
        summary = file.read()

    # List of analysis types to perform
    analysis_types = ["contradiction", "completeness", "qa_score", "coherence"]

    # Perform analysis for each analysis type
    for analysis_type in analysis_types:
        table_format, range_info = analyze_metrics(paragraph, summary, analysis_type=analysis_type)
        print(f"\n{analysis_type.capitalize()} Analysis - Table Format:")
        print(json.dumps(table_format, indent=4))
        print(f"\n{analysis_type.capitalize()} Analysis - Range Info:")
        print(json.dumps(range_info, indent=4))

