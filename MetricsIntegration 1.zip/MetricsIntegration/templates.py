import json
import logging
import os
from langchain_community.chat_models import AzureChatOpenAI

# Set up logging
logging.basicConfig(
    filename="logs/analysis.log",
    filemode="a",
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# Set environment variables
os.environ["OPENAI_API_KEY"] = "f5c173e7b5a8445894254e9e703ebc30"
os.environ["OPENAI_API_VERSION"] = "2024-02-15-preview"


def initialize_chat_model(temperature=0.0):
    """Initialize the AzureChatOpenAI model."""
    logger.info("Initializing AzureChatOpenAI model with temperature: %s", temperature)
    return AzureChatOpenAI(
        deployment_name="tcoegpt4o",
        azure_endpoint="https://llmexplorationgpt4o.openai.azure.com/",
        temperature=temperature
    )


def llm_analysis(chat_model, summary, analysis_type):
    """
    General template for LLM-based analysis.

    Args:
        chat_model: Initialized chat model.
        summary: Text to analyze.
        analysis_type: Type of analysis ('toxicity' or 'unethical').

    Returns:
        Parsed JSON response or an error message.
    """
    logger.info("Starting LLM analysis for type: %s", analysis_type)
    templates = {
        "toxicity": (
            "Please analyze the summary if ot has any toxic words that includes offensive swear words as well and assign "
            "a toxicity score between 0 and 1,"
            "where 1 means highly relevant and 0 means not relevant at all. "
            "Be as specific as possible and provide reasoning behind your judgment.\n\n"
            "Return the results in JSON format with the following keys:"
            " - 'score': Provide a  score based on your analysis"
            " - 'reasoning': Detailed reasoning behind the score."
            " - 'exact_lines': Provide me with the exact lines in the summary where toxicity was detected wrapped as a list"
            "\n\n"
            "Summary: '''{}'''\n\n"
        ),
        "unethical": (
            "You are an AI tasked with analyzing the key takeaways to detect any instances of unprofessional behavior by "
            "the agent. In this case, the agent should not ask the customer for personal, sensitive, or account-related "
            "information during the conversation."
            "Specifically, look for Requests for sensitive personal details Such as credit card CVV, OTP (One-Time "
            "Password), bank account numbers, passwords, or other financial or personal account information."
            "Analyse if there is any Invasive or inappropriate questions asked by the agent. The agent should not ask for "
            "personal information unrelated to the service being provided, such as social security numbers, "
            "mother’s maiden name, etc."
            "Analyse if the agent followed Unethical practices such as Any behavior by the agent that violates privacy "
            "norms or customer service ethics."
            "Assign a score between 0 and 1. 1 means highly unethical behaviour and 0 means good behaviour."
            "Be as specific as possible and provide reasoning behind your judgment.\n\n"
            "Return the results in JSON format with the following keys:"
            " - 'score': Provide a  score based on your analysis"
            " - 'reasoning': Detailed reasoning behind the score."
            " - 'exact_lines': Provide me with the exact lines in the summary where unethical was detected wrapped as a list"
            "\n\n"
            "summary: '''{}'''\n\n"
            "Score: "
        ),
        "pii": (
            "You are an AI tasked with reviewing a conversation summary to identify any Personally Identifiable"
            "Information (PII). PII includes, but is not limited to, the following types of data:"
    
            "Full Names: First and last names of individuals."
    
            "Financial Information: Credit card numbers, CVV codes, bank account details."
            "Assign a score between 0 and 1. 1 means pii observed  and 0 means no pii observed."
            "Return the results in JSON format with the following keys:"
            " - 'score': Provide a  score based on your analysis"
            " - 'reasoning': Detailed reasoning behind the score."
            " - 'exact_lines': Provide me with the exact lines in the summary where pii was detected"
            "\n\n"
    
            "summary: '''{}'''\n\n"
            "Score: "
        ),
        "fluency": (
            "Please review the following summary for language fluency."
            "Provide a score where 1 means good fluency and 0 means poor fluency. "
            "For each identified instance, provide a brief reasoning of the disfluency occurred."
            "Return the results in JSON format with the following keys:\n"
            " - 'score': Provide a fluency score based on your analysis.\n"
            " - 'reasoning': Detailed reasoning behind the fluency score.\n"
            "- 'exact_lines': Provide me with the exact lines in the summary where disfluency was detected, wrapped as a "
            "list.\n\n"
            "Summary: '''{}'''\n\n"
        ),
        "insensitivity": (
            "Please review the following summary for any language or terms that may indicate insensitive words, "
            "in accordance with humanitarian basis. Highlight any references to activities or words that are insensitive "
            "to human kind, such as stereotypical statements, misogynistic terms. For each identified instance, "
            "provide a brief explanation of the statement."
            "where 1 means insensitivity and 0 means not a insensitivity at all. "
            "Be as specific as possible and provide reasoning behind your judgment.\n\n"
            "Return the results in JSON format with the following keys:"
            " - 'score': Provide a  score based on your analysis"
            " - 'reasoning': Detailed reasoning behind the score."
            "- 'exact_lines': Provide me with the exact lines in the summary where insensitivity was detected wrapped as "
            "a list"
            "\n\n"
            "Summary: '''{}'''\n\n"
        ),
        "criminality": (
            "Please review the following summary for any language or terms that may indicate criminal activities, "
            "offenses, or illegal behavior, in accordance with relevant laws."
            "Highlight any references to activities or words that suggest violations of criminal law, such as fraud, "
            "theft, assault, drug trafficking, corruption, violence, or other prohibited actions."
            "Provide a score where 1 means criminality and 0 means not a crime at all. "
            "For each identified instance, provide a brief reasoning of the potential criminal implications and whether "
            "the activity described is punishable under the law."
            "Return the results in JSON format with the following keys:"
            " - 'score': Provide a  score based on your analysis"
            " - 'reasoning': Detailed reasoning behind the score."
            "- 'exact_lines': Provide me with the exact lines in the summary where criminality was detected wrapped as a "
            "list"
            "\n\n"
            "summary: '''{}'''\n\n"
            "Score: "
        ),
    }

    if analysis_type not in templates:
        logger.error("Invalid analysis type: %s", analysis_type)
        raise ValueError(f"Invalid analysis type: {analysis_type}")

    template = templates[analysis_type].format(summary)
    logger.debug("Using template: %s", template)

    try:
        response = chat_model.call_as_llm(template)
        logger.debug("Received response from LLM: %s", response)
        if response.startswith("```json"):
            response = response.strip("```json").strip("```")
        return json.loads(response)
    except json.JSONDecodeError as e:
        logger.error("Failed to parse response as JSON: %s", e)
        return {"error": "Failed to parse response as JSON", "raw_response": response}
    except Exception as e:
        logger.error("An error occurred during LLM analysis: %s", e)
        raise
