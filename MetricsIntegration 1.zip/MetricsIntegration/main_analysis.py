import json
import logging
from templates import initialize_chat_model, llm_analysis
from char_index_check import extract_exact_lines, line_start_end_index_from_file
import warnings

# Set up logging
logging.basicConfig(
    filename="logs/analysis.log",
    filemode="a",
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

warnings.filterwarnings("ignore", category=DeprecationWarning)


def analyze_text(file_path, analysis_type):
    """
    Analyze text for a specified type of analysis.

    Args:
        file_path: Path to the input text file.
        analysis_type: Type of analysis ('toxicity', 'unethical', 'pii', 'fluency', 'insensitivity', 'criminality'. etc.).

    Returns:
        Dictionary with analysis results.
    """
    logger.info("Starting analysis for file: %s with analysis type: %s", file_path, analysis_type)

    try:
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        logger.error("File '%s' not found.", file_path)
        return {"error": f"The file '{file_path}' was not found."}

    logger.debug("File content read successfully.")

    chat_model = initialize_chat_model()
    logger.debug("Chat model initialized.")

    try:
        results = llm_analysis(chat_model, text, analysis_type)
        logger.info("LLM analysis completed for type: %s", analysis_type)
    except Exception as e:
        logger.error("Error during LLM analysis: %s", e)
        return {"error": f"LLM analysis failed for type {analysis_type}.", "details": str(e)}

    exact_lines = extract_exact_lines(results)
    logger.debug("Extracted exact lines: %s", exact_lines)

    range_indices = line_start_end_index_from_file(exact_lines, file_path)
    logger.debug("Computed range indices: %s", range_indices)

    results['range'] = range_indices['range']
    logger.info("Analysis completed successfully for type: %s", analysis_type)

    return results


if __name__ == "__main__":
    # Define the file path and the analysis types to be performed
    file_path = 'summary.txt'
    analysis_types = [
        "toxicity", "unethical", "pii", "fluency",
        "insensitivity", "criminality"
    ]

    logger.info("Starting main analysis script.")
    for analysis_type in analysis_types:
        logger.info("Performing %s analysis.", analysis_type)
        try:
            analysis_results = analyze_text(file_path, analysis_type=analysis_type)
            print(f"\n{analysis_type.capitalize()} Analysis Results:")
            print(json.dumps(analysis_results, indent=4))
        except Exception as e:
            logger.error("Error during analysis for type %s: %s", analysis_type, e)
            print(f"Error analyzing {analysis_type}: {e}")
    logger.info("Main analysis script completed.")
