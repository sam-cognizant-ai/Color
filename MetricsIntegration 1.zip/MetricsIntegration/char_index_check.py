import logging

# Set up logging
logging.basicConfig(
    filename="logs/analysis.log",
    filemode="a",
    level=logging.DEBUG,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


def extract_exact_lines(results):
    """Extract 'exact_lines' values from the analysis results."""
    logger.info("Extracting 'exact_lines' from the results.")
    exact_lines = results.get('exact_lines', [])
    if exact_lines:
        logger.debug("Extracted lines: %s", exact_lines)
    else:
        logger.warning("No 'exact_lines' found in the results.")
    return exact_lines


def line_start_end_index_from_file(lines_to_check, file_path='summary.txt'):
    """Find the indices of specific lines in a text file."""
    logger.info("Finding line start-end indices in file: %s", file_path)
    try:
        with open(file_path, 'r') as file:
            text = file.read()
    except FileNotFoundError:
        logger.error("File '%s' not found.", file_path)
        return f"The file '{file_path}' was not found."

    all_indices = []
    for line_to_check in lines_to_check:
        line_to_check = line_to_check.strip()
        indices = []
        start_index = 0

        while True:
            start_index = text.find(line_to_check, start_index)
            if start_index == -1:
                break
            end_index = start_index + len(line_to_check) - 1
            indices.append([start_index, end_index])
            start_index += 1

        if indices:
            logger.debug("Found indices for line '%s': %s", line_to_check, indices)
            all_indices.extend(indices)
        else:
            logger.warning("No indices found for line: '%s'", line_to_check)

    result = {
        "range": {
            "input": {"red": [], "green": []},
            "summary": {"red": all_indices, "green": []}
        }
    }
    logger.info("Completed index calculation. Result: %s", result)
    return result
