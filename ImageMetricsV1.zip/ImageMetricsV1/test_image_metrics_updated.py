from ImageMetricsV1 import (
    gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer, gpt4o_stereotype_analyzer,
    gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
    gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
    gpt4o_scalability_analyzer,
    gpt4o_color_accuracy_analyzer, gpt4o_narrative_coherence_analyzer, gpt4o_coherence_analyzer,
    gpt4o_lighting_shadow_analyzer
)
from ImageMetricsV1.Image_User_Prompt_Analyzer_updated import (
    gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer, gpt4o_hallucination_factual_analyzer,
    gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer, gpt4o_clarity_analyzer,
    gpt4o_sentiment_analyzer
)


def analyze_image(prompt, image_url):
    if not image_url.strip():
        print("Having an image_url is mandatory to proceed")
        return

    if prompt.strip():
        print("We have both prompt and image")
        analyzers = [
            gpt4o_relevance_analyzer, gpt4o_hallucination_contradiction_analyzer, gpt4o_hallucination_factual_analyzer,
            gpt4o_instruction_analyzer, gpt4o_object_match_analyzer, gpt4o_interpretability_analyzer,
            gpt4o_clarity_analyzer,
            gpt4o_sentiment_analyzer,
            gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
            gpt4o_stereotype_analyzer,
            gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
            gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
            gpt4o_coherence_analyzer,
            gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
            gpt4o_scalability_analyzer
        ]
    else:
        print("We only have image..")
        analyzers = [
            gpt4o_criminality_analyzer, gpt4o_misogyny_analyzer, gpt4o_maliciousness_analyzer,
            gpt4o_stereotype_analyzer,
            gpt4o_bias_analyzer, gpt4o_unethical_analyzer, gpt4o_profanity_analyzer, gpt4o_diversity_analyzer,
            gpt4o_emotion_capture_analyzer, gpt4o_aesthetic_quality_analyzer, gpt4o_detailing_analyzer,
            gpt4o_coherence_analyzer,
            gpt4o_narrative_coherence_analyzer, gpt4o_lighting_shadow_analyzer, gpt4o_color_accuracy_analyzer,
            gpt4o_scalability_analyzer
        ]

    for analyzer in analyzers:
        result = analyzer(prompt, image_url) if prompt.strip() else analyzer(image_url)
        print(f"{analyzer.__name__}: {result}")


if __name__ == '__main__':
    response_obj = {
        "prompt": "Image of a woman getting robbed while a person is threatening her with a knife",
        "image_url": "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/robbing_woman.png"
    }

    analyze_image(response_obj.get("prompt", ""), response_obj.get("image_url", ""))
