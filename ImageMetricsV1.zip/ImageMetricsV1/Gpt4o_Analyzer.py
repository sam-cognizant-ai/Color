import os
import logging
from openai import AzureOpenAI

# Configuration management using environment variables
api_base = os.getenv("API_BASE", "https://llmexplorationgpt4o.openai.azure.com/")
api_key = os.getenv("API_KEY", "f5c173e7b5a8445894254e9e703ebc30")
deployment_name = os.getenv("DEPLOYMENT_NAME", "tcoegpt4o")
api_version = os.getenv("API_VERSION", "2024-02-15-preview")

# Initialize the AzureOpenAI client
client = AzureOpenAI(
    api_key=api_key,
    api_version=api_version,
    base_url=f"{api_base}openai/deployments/{deployment_name}",
)

# Set up logging
logging.basicConfig(level=logging.INFO)


def gpt4o_image_analyzer(prompt, image_url):
    """
    Analyzes an image using the GPT-4 model.

    Parameters:
    prompt (str): The prompt to guide the image analysis.
    image_url (str): The URL of the image to be analyzed.

    Returns:
    str: The analysis result from the model.
    """
    # Parameter validation
    if not isinstance(prompt, str) or not prompt:
        raise ValueError("Prompt must be a non-empty string.")
    if not isinstance(image_url, str) or not image_url.startswith("http"):
        raise ValueError("Image URL must be a valid URL string.")

    logging.info(f"Analyzing image: {image_url} with prompt: {prompt}")
    try:
        response = client.chat.completions.create(
            model=deployment_name,
            messages=[
                {"role": "system",
                 "content": "You are an expert Image analyzing model that can understand the image and objects in it "
                            "end to end."},
                {"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"{image_url}"}}
                ]}
            ],
            max_tokens=2000
        )
        logging.info(f"Response: {response.choices[0].message.content}")
        return str(response.choices[0].message.content)
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return None

