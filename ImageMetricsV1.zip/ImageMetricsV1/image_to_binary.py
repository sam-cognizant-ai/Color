import requests
from pymongo import MongoClient
import gridfs
from PIL import Image
import io
import hashlib


def store_image_in_grid_fs(image_url, db_name, collection_name):
    try:
        # Fetch the image from the URL
        response = requests.get(image_url)
        response.raise_for_status()  # Raise an error for bad status codes

        # Convert the image data to binary format
        image_data = response.content

        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017')
        db = client[db_name]
        fs = gridfs.GridFS(db, collection=collection_name)

        # Store the binary data in GridFS
        file_id = fs.put(image_data, filename=image_url.split("/")[-1])

        print(f"Image stored in GridFS with file ID: {file_id}")

    except requests.RequestException as e:
        print(f"Error fetching the image: {e}")
    except Exception as e:
        print(f"Error storing the image in GridFS: {e}")


def retrieve_and_verify_image(image_url, db_name, collection_name):
    try:
        # Fetch the original image from the URL
        response = requests.get(image_url)
        response.raise_for_status()
        original_image_data = response.content

        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017')
        db = client[db_name]
        fs = gridfs.GridFS(db, collection=collection_name)

        # Retrieve the image from GridFS
        filename = image_url.split("/")[-1]
        stored_image_data = fs.find_one({"filename": filename}).read()

        # Verify if the original image data matches the stored image data
        if hashlib.md5(original_image_data).hexdigest() == hashlib.md5(stored_image_data).hexdigest():
            print("The retrieved image matches the original image.")
        else:
            print("The retrieved image does not match the original image.")

    except requests.RequestException as e:
        print(f"Error fetching the original image: {e}")
    except Exception as e:
        print(f"Error retrieving or verifying the image from GridFS: {e}")


def display_image_from_gridfs(image_url, db_name, collection_name):
    try:
        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017')
        db = client[db_name]
        fs = gridfs.GridFS(db, collection=collection_name)

        # Retrieve the image from GridFS
        filename = image_url.split("/")[-1]
        stored_image_data = fs.find_one({"filename": filename}).read()

        # Display the image
        image = Image.open(io.BytesIO(stored_image_data))
        image.show()

    except Exception as e:
        print(f"Error displaying the image from GridFS: {e}")


# Example usage
image_url = "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/girl_boy_playing.jpg"
db_name = "GenAIAssuranceDatabase"
collection_name = "grid-FS"

store_image_in_grid_fs(image_url, db_name, collection_name)
retrieve_and_verify_image(image_url, db_name, collection_name)
display_image_from_gridfs(image_url, db_name, collection_name)
