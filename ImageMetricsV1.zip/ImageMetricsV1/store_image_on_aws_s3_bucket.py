import boto3
import requests
from pymongo import MongoClient
from PIL import Image
import io


def upload_image_to_s3(image_url, bucket_name, s3_filename):
    try:
        # Fetch the image from the URL
        response = requests.get(image_url)
        response.raise_for_status()
        image_data = response.content

        # Upload to S3
        s3 = boto3.client('s3', aws_access_key_id='your-access-key-id', aws_secret_access_key='your-secret-access-key')
        s3.put_object(Bucket=bucket_name, Key=s3_filename, Body=image_data)

        # Generate the S3 URL
        s3_url = f"https://{bucket_name}.s3.amazonaws.com/{s3_filename}"
        print(f"Image uploaded to S3 with URL: {s3_url}")
        return s3_url

    except requests.RequestException as e:
        print(f"Error fetching the image: {e}")
    except Exception as e:
        print(f"Error uploading the image to S3: {e}")


def store_url_in_mongodb(url, db_name, collection_name):
    try:
        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017')
        db = client[db_name]
        collection = db[collection_name]

        # Store the URL
        document = {"url": url}
        collection.insert_one(document)

        print(f"URL stored in MongoDB: {url}")

    except Exception as e:
        print(f"Error storing URL in MongoDB: {e}")


def retrieve_and_display_image_from_url(db_name, collection_name):
    try:
        # Connect to MongoDB
        client = MongoClient('mongodb://localhost:27017')
        db = client[db_name]
        collection = db[collection_name]

        # Retrieve the URL
        document = collection.find_one()
        if document:
            url = document.get("url")
            print(f"URL retrieved from MongoDB: {url}")

            # Fetch the image from the URL
            response = requests.get(url)
            response.raise_for_status()
            image_data = response.content

            # Display the image
            image = Image.open(io.BytesIO(image_data))
            image.show()
        else:
            print("No URL found in MongoDB")

    except Exception as e:
        print(f"Error retrieving or displaying the image: {e}")


# Example usage
image_url = "https://qafastest.cognizant.com/fastestLiteFiles/sreesuryas-genai-testing/images/robbing_woman.png"
bucket_name = "your-s3-bucket-name"
s3_filename = "robbing_woman.png"
db_name = "GenAIAssuranceDatabase"
collection_name = "image_metadata"

s3_url = upload_image_to_s3(image_url, bucket_name, s3_filename)
store_url_in_mongodb(s3_url, db_name, collection_name)
retrieve_and_display_image_from_url(db_name, collection_name)
